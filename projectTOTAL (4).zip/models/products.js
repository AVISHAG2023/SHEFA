const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        require: true
    },

    price: {
        type: Number,
        require: true,
        min: 0

    },
    category: {
        type: String,
        require: true
    },
    quantity: {
        type: Number,
        require: true,
        min: 0
    },


})
const Product = mongoose.model('Product', productSchema);

Product.insertMany([
    { name: "גבינה", price: 5.00, category: 'milk', quantity: 0 },
    { name: "דנונה פרו שטראוס", price: 6.00, category: 'milk', quantity: 0 },
    { name: "חלב יטבתה", price: 5.00, category: 'milk', quantity: 0 },
    { name: "קוטג'", price: 6.00, category: 'milk', quantity: 0 },
    { name: "גבינה צהובה", price: 24.00, category: 'milk', quantity: 0 },
    { name: "חלב עיזים", price: 9.00, category: 'milk', quantity: 0 },
    { name: "יופלה משקה יוגורט", price: 8.00, category: 'milk', quantity: 0 },
    { name: "משקה פונץ' בננה", price: 7.00, category: 'milk', quantity: 0 },
    { name: "משקה מוקה", price: 7.00, category: 'milk', quantity: 0 },
    { name: "משקה אייס קפה", price: 7.00, category: 'milk', quantity: 0 },
    { name: "משקה בננה", price: 7.00, category: 'milk', quantity: 0 },
    { name: "משקה שוקו", price: 7.00, category: 'milk', quantity: 0 },
    { name: "שמנת להקצפה", price: 5.00, category: 'milk', quantity: 0 },
    { name: "שמנת לבישול", price: 5.00, category: 'milk', quantity: 0 },
    { name: "רוטב שמנת עם פטריות", price: 6.00, category: 'milk', quantity: 0 },
    { name: "משקה שיבולת שועל", price: 7.00, category: 'milk', quantity: 0 },
    { name: "גבינת שמנת נפוליון", price: 11.00, category: 'milk', quantity: 0 },
    { name: "משקה סויה", price: 12.00, category: 'milk', quantity: 0 },
    { name: "גבינה מותכת", price: 18.00, category: 'milk', quantity: 0 },
    { name: "בולגרית מעודנת", price: 24.00, category: 'milk', quantity: 0 },
    { name: "מוצרלה טרה", price: 27.00, category: 'milk', quantity: 0 },
    { name: 'גמבה אדומה', price: 5.90, category: 'vegetables', quantity: 0 },
    { name: 'מלפפון', price: 2.90, category: 'vegetables', quantity: 0 },
    { name: 'בצל', price: 6.90, category: 'vegetables', quantity: 0 },
    { name: 'בטטה', price: 7.90, category: 'vegetables', quantity: 0 },
    { name: 'עגבניה', price: 3.90, category: 'vegetables', quantity: 0 },
    { name: 'לימון', price: 13.90, category: 'vegetables', quantity: 0 },
    { name: 'תפוח אדמה אדום', price: 4.90, category: 'vegetables', quantity: 0 },
    { name: 'תפוח אדמה לבן', price: 4.90, category: 'vegetables', quantity: 0 },
    { name: 'שום', price: 5,category: 'vegetables', quantity: 0 },
    { name: 'בצל סגול', price: 9.90, category: 'vegetables', quantity: 0 },
    { name: 'גזר', price: 5.90, category: 'vegetables', quantity: 0 },
    { name: 'כרוב אדום', price: 9.90, category: 'vegetables', quantity: 0 },
    { name: 'חציל', price: 7.90, category: 'vegetables', quantity: 0 },
    { name: 'דלורית', price: 12.90, category: 'vegetables', quantity: 0 },
    { name: 'דלעת', price: 15.90, category: 'vegetables', quantity: 0 },
    { name: 'סלק אדום', price: 2.90, category: 'vegetables', quantity: 0 },
    { name: 'כרובית', price: 11.90, category: 'vegetables', quantity: 0 },
    { name: "מארז תות שדה", price: 20.00, category: 'fruit', quantity: 0 },
    { name: "תפוח חרמון מובחר", price: 15.90, category: 'fruit', quantity: 0 },
    { name: "אוכמניות", price: 15.00, category: 'fruit', quantity: 0 },
    { name: "פטל אדום", price: 25.00, category: 'fruit', quantity: 0 },
    { name: "תפוז מובחר", price: 9.90, category: 'fruit', quantity: 0 },
    { name: "אגס ירוק מובחר", price: 18.90, category: 'fruit', quantity: 0 },
    { name: "אננס", price: 30.00, category: 'fruit', quantity: 0 },
    { name: "קלמנטינה", price: 7.90, category: 'fruit', quantity: 0 },
    { name: "פפאיה חתוכה", price: 20.00, category: 'fruit', quantity: 0 },
    { name: "חצי אבטיח", price: 7.90, category: 'fruit', quantity: 0 },
    { name: "מארז פסיפלורה", price: 15.00, category: 'fruit', quantity: 0 },
    { name: "בננה מובחרת", price: 10.90, category: 'fruit', quantity: 0 },
    { name: "ענבים ירוקים", price: 20.90, category: 'fruit', quantity: 0 },
    { name: "ענבים שחורים", price: 20.90, category: 'fruit', quantity: 0 },
    { name: "שזיף אדום", price: 26.90, category: 'fruit', quantity: 0 },
    { name: "גויאבה", price: 13.90, category: 'fruit', quantity: 0 },
    { name: "קיווי ירוק", price: 17.90, category: 'fruit', quantity: 0 },
    { name: "סברס", price: 13.90, category: 'fruit', quantity: 0 },
    { name: "רימון", price: 19.90, category: 'fruit', quantity: 0 },
    { name: "מלון", price: 16.90, category: 'fruit', quantity: 0 },
    { name: "אפרסמון מובחר", price: 9.90, category: 'fruit', quantity: 0 },
    { name: "פומלה", price: 8.90, category: 'fruit', quantity: 0 },
    { name: "אשכולית אדומה", price: 5.90, category: 'fruit', quantity: 0 }
]).then(data => {
    console.log('it works!!');
})
    .catch(err => {

        console.log(err);
    })

