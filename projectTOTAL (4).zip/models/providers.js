const mongoose = require('mongoose');
const providerSchema = new mongoose.Schema({
    name: {
        type: String,
        require: true
    },

    adress: {
        type: String,
        require: true
    },

    category: {
        type: String,
        require: true
    },

    phone: {
        type: Number,
        require: true
    },

})
const Providers = mongoose.model('provider', providerSchema);
Providers.insertMany([
    { name: "תוצרת המושב", adress: "תדהר", category: "ירקות", phone: 076 - 8608670 },
    { name: "פרי השדה", adress: "גנות", category: "פירות", phone: 072 - 3341835 },
    { name: " תנובה מרקט", adress: "כפר תבור", category: "חלב", phone: 04 - 6620443 }

]).then(data => {
    console.log('it works!!');
})
    .catch(err => {

        console.log(err);
    })