const milk = [
    { name: "גבינה", price: 5.00, quantity: 0 },
    { name: "דנונה פרו שטראוס", price: 6.00, quantity: 0 },
    { name: "חלב יטבתה", price: 5.00, quantity: 0 },
    { name: "קוטג'", price: 6.00, quantity: 0 },
    { name: "גבינה צהובה", price: 24.00, quantity: 0 },
    { name: "חלב עיזים", price: 9.00, quantity: 0 },
    { name: "יופלה משקה יוגורט", price: 8.00, quantity: 0 },
    { name: "משקה פונץ' בננה", price: 7.00, quantity: 0 },
    { name: "משקה מוקה", price: 7.00, quantity: 0 },
    { name: "משקה אייס קפה", price: 7.00, quantity: 0 },
    { name: "משקה בננה", price: 7.00, quantity: 0 },
    { name: "משקה שוקו", price: 7.00, quantity: 0 },
    { name: "שמנת להקצפה", price: 5.00, quantity: 0 },
    { name: "שמנת לבישול", price: 5.00, quantity: 0 },
    { name: "רוטב שמנת עם פטריות", price: 6.00, quantity: 0 },
    { name: "משקה שיבולת שועל", price: 7.00, quantity: 0 },
    { name: "גבינת שמנת נפוליון", price: 11.00, quantity: 0 },
    { name: "משקה סויה", price: 12.00, quantity: 0 },
    { name: "גבינה מותכת", price: 18.00, quantity: 0 },
    { name: "בולגרית מעודנת", price: 24.00, quantity: 0 },
    { name: "מוצרלה טרה", price: 27.00, quantity: 0 }
];
let shoppingCart = [];

const fruit = [
            { name: "מארז תות שדה", price: 20.00, quantity: 0 },
            { name: "תפוח חרמון מובחר", price: 15.90, quantity: 0 },
            { name: "אוכמניות", price: 15.00, quantity: 0 },
            { name: "פטל אדום", price: 25.00, quantity: 0 },
            { name: "תפוז מובחר", price: 9.90, quantity: 0 },
            { name: "אגס ירוק מובחר", price: 18.90, quantity: 0 },
            { name: "אננס", price: 30.00, quantity: 0 },
            { name: "קלמנטינה", price: 7.90, quantity: 0 },
            { name: "פפאיה חתוכה", price: 20.00, quantity: 0 },
            { name: "חצי אבטיח", price: 7.90, quantity: 0 },
            { name: "מארז פסיפלורה", price: 15.00, quantity: 0 },
            { name: "בננה מובחרת", price: 10.90, quantity: 0 },
            { name: "ענבים ירוקים", price: 20.90, quantity: 0 },
            { name: "ענבים שחורים", price: 20.90, quantity: 0 },
            { name: "שזיף אדום", price: 26.90, quantity: 0 },
            { name: "גויאבה", price: 13.90, quantity: 0 },
            { name: "קיווי ירוק", price: 17.90, quantity: 0 },
            { name: "סברס", price: 13.90, quantity: 0 },
            { name: "רימון", price: 19.90, quantity: 0 },
            { name: "מלון", price: 16.90, quantity: 0 },
            { name: "אפרסמון מובחר", price: 9.90, quantity: 0 },
            { name: "פומלה", price: 8.90, quantity: 0 },
            { name: "אשכולית אדומה", price: 5.90, quantity: 0 }
];
const vegetables = [
    { name: 'גמבה אדומה', price: 5.90, quantity: 0 },
    { name: 'מלפפון', price: 2.90, quantity: 0 },
    { name: 'בצל', price: 6.90, quantity: 0 },
    { name: 'בטטה', price: 7.90, quantity: 0 },
    { name: 'עגבניה', price: 3.90, quantity: 0 },
    { name: 'לימון', price: 13.90, quantity: 0 },
    { name: 'תפוח אדמה אדום', price: 4.90, quantity: 0 },
    { name: 'תפוח אדמה לבן', price: 4.90, quantity: 0 },
    { name: 'שום', price: 5, quantity: 0 },
    { name: 'בצל סגול', price: 9.90, quantity: 0 },
    { name: 'גזר', price: 5.90, quantity: 0 },
    { name: 'כרוב אדום', price: 9.90, quantity: 0 },
    { name: 'חציל', price: 7.90, quantity: 0 },
    { name: 'דלורית', price: 12.90, quantity: 0 },
    { name: 'דלעת', price: 15.90, quantity: 0 },
    { name: 'סלק אדום', price: 2.90, quantity: 0 },
    { name: 'כרובית', price: 11.90, quantity: 0 },
];

function updateQuantity(nameArray, index, delta) {

    let currentArr = [];
    switch (nameArray) {
        case 'milk':
            currentArr = milk
            break;
        case 'fruit':
            currentArr = fruit
            break
        case 'vegetables':
            currentArr = vegetables
            break
        default:
            break;
    }
    currentArr[index].quantity += delta;
    if (currentArr[index].quantity < 0) {
        currentArr[index].quantity = 0;
    }
    document.getElementById("quantity" + index).innerHTML = currentArr[index].quantity;
    calculateTotal(currentArr);
    addToCart(index, currentArr[index].name, currentArr[index].price);
}
function calculateTotal(currentArr) {
    let total = 0;
    for (let i = 0; i < currentArr.length; i++) {
        total += currentArr[i].price * currentArr[i].quantity;
    }
    document.getElementById("total").innerHTML = total;
}

// function addToCart(arr) {
//     let cart = "";
//     for (let i = 0; i < arr.length; i++) {
//         if (arr[i].quantity > 0) {
//             cart += arr[i].name + " x " + arr[i].quantity + "\n";
//         }
//     }
//     if (cart === "") {
//         alert("אנא בחר לפחות מוצר אחד להוספה לסל!");
//     } else {
//         alert("המוצרים הבאים נוספו לסל:\n\n" + cart + "\nסך הכל: " + document.getElementById("total").innerHTML + " שקלים");
//     }
// }



function addToCart(id, name, price) {
    let product = {
        id: id,
        name: name,
        price: price
    };
    shoppingCart.push(product);
}

function generateTable() {

    // creates a <table> element and a <tbody> element
    const tbl = document.createElement("table");
    const tblBody = document.createElement("tbody");

    let headerRow = tbl.insertRow();
    headerRow.innerHTML = '<th>Product</th><th>Price</th>';
    // creating all cells
    //  for (let i = 0; i < 2; i++) 
        // creates a table row
        const row = document.createElement("tr");

        //for (let j = 0; j < 2; j++) {
        for (let product of shoppingCart) {
            // let row = tbl.insertRow();
            // row.innerHTML = `<td>${product.name}</td><td>${product.price}</td>`;

            // Create a <td> element and a text node, make the text
            // node the contents of the <td>, and put the <td> at
            // the end of the table row
            const cell = document.createElement("td");
            console.log("product", product.name)
            cell.innerHTML = `<td>${product.name}</td><td>${product.price}</td>`;
            const cellText = document.createTextNode(`cell in row ${i}, column ${j}`);
            cell.appendChild(cellText);
            row.appendChild(cell);
        }
    
        // add the row to the end of the table body
        tblBody.appendChild(row);
    

    // put the <tbody> in the <table>
    tbl.appendChild(tblBody);
    // appends <table> into <body>
    document.body.appendChild(tbl);
    // sets the border attribute of tbl to '2'
    tbl.setAttribute("border", "2");
}

function updateCartUI() {
    let cartContentsElement = document.getElementById('cart-contents').innerHTML;
    console.log("lslslsl", cartContentsElement)
    cartContentsElement.innerHTML = '';

    let cartTable = document.createElement('table');
    console.log("table", cartTable)

    let headerRow = cartTable.insertRow();
    headerRow.innerHTML = '<th>Product</th><th>Price</th>';

    for (let product of shoppingCart) {
        let row = cartTable.insertRow();
        row.innerHTML = `<td>${product.name}</td><td>${product.price}</td>`;
    }

}



